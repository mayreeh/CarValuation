<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
  	<script type='text/javascript' src="<?php echo base_url(); ?>js/jquery-ui.js"></script>
	<script type='text/javascript' src="<?php echo base_url(); ?>js/jquery.maskedinput.js"></script>

<h5>Search for Valuation Report</h5>
<p>Provide the registration number of the motor vehicle whose valuation report you wish to view:</p>
<form action="<?php base_url(); ?>search" method="get">
	<input type="text" name="q" id="q" placeholder="KZZ 999Z" class="search-term-large w300px" />
	<div class="clear"></div>
	<input type="submit" value="Search" class="blue" />
</form>