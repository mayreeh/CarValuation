<div class="col_12">
	<h5><?php echo $notification['title']; ?></h5>
	<div class="notice <?php echo $notification['class']; ?>"><?php echo $notification['text']; ?></div>
</div>