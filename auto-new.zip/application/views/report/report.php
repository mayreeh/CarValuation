<h2>My Report Heading</h2>

<p>This is the first of many reports.</p>

<p><strong>This is my bold text.</strong></p>