<!-- Load the pdf file -->
<?php $this->load->view('report/details'); ?>