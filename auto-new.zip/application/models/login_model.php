<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model {

	// Constructor
	public function __construct()
	{
		parent::__construct();
	}

}